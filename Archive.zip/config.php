<?php
// Tên miền host
$host = "localhost";
//Tài khoản PHP myadmin
$tentaikhoan = "root";
// mật khẩu PHP myadmin
$matkhau = "conco";
//Tên cơ sở dữ liệu
$DB = "diem";

define("DEFAULT_USERNAME",$tentaikhoan);
define("DEFAULT_PASSWORD",$matkhau);
define("DATABASE_NAME",$DB);
define("HOST_NAME",$host);



 ?>
