<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>UTT</title>
	<link rel="stylesheet" href="admin/font-awesome/css/font-awesome.css">
	<!-- Google Fonts -->
	<link href="style/fonts/google-font.css" rel='stylesheet' type='text/css'>
	<!-- favicon -->
	<link rel="shortcut icon" href="images/utt-copy.png">
	<link rel="stylesheet" href="style/animate.css">
	<!-- Custom Stylesheet -->
	<link rel="stylesheet" href="style/style.css">
	<link id="bootstrap" rel="stylesheet" href="style/css/bootstrap.min.css">
	<link id="gv" rel="stylesheet" href="#">
  <!-- jquery -->
	<script src="style/js/jquery.min.js"></script>
  <script src="style/js/bootstrap.min.js"></script>
</head>

<body>
  <header>
    <section>
      <div class="container">
        <div class="row">
          <span><img src="images/utt.png" alt="" width="100px" height="auto"></span><marquee><h4>2017 Trường Đại học Công nghệ Giao thông vận tải.</h4></marquee>
        </div>
      </div>
    </section>
  </header>
