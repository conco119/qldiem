<footer>
    <div class="footer" id="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
                    <h3>Thông tin liên hệ</h3>
                    <ul>
                        <li> <a href="#"> Số 54 Triều Khúc, Thanh Xuân, Hà Nội.</a> </li>
                        <li> <a href="#"> Điện thoại: 043.854.4264</a> </li>
                        <li> <a href="#">Fax: 043.854.7695</a> </li>
                    </ul>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
                    <h3>Tuyển sinh</h3>
                    <ul>
                        <li> <a href="#">  Tuyển sinh </a> </li>
                        <li> <a href="#">  Đào tạo ngắn hạn </a> </li>
                        <li> <a href="#">  Tra cứu điểm thi </a> </li>
                    </ul>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
                    <h3> Chương trình học </h3>
                    <ul>
                        <li> <a href="#">  Đại học chính quy </a> </li>
                        <li> <a href="#">  Thạc sĩ </a> </li>
                        <li> <a href="#">  Dự bị du học </a> </li>
                    </ul>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
                    <h3> Môi trường học </h3>
                    <ul>
                        <li> <a href="#"> Cơ sở vật chất </a> </li>
                        <li> <a href="#">  Ký túc xá </a> </li>
                        <li> <a href="#">  Thư viện </a> </li>
                    </ul>
                </div>
                <div class="col-lg-3  col-md-3 col-sm-6 col-xs-12 ">
                    <h3> Mạng xã hội </h3>
                    <ul class="social">
                        <li> <a href="#"> <i class=" fa fa-facebook">   </i> </a> </li>
                        <li> <a href="#"> <i class="fa fa-twitter">   </i> </a> </li>
                        <li> <a href="#"> <i class="fa fa-google-plus">   </i> </a> </li>
                        <li> <a href="#"> <i class="fa fa-pinterest">   </i> </a> </li>
                        <li> <a href="#"> <i class="fa fa-youtube">   </i> </a> </li>
                    </ul>
                </div>
            </div>
            <!--/.row-->
        </div>
        <!--/.container-->
    </div>
    <!--/.footer-->

    <div class="footer-bottom">
        <div class="container">
            <p class="pull-left"> © 2017 Trường Đại học Công nghệ Giao thông vận tải. </p>
        </div>
    </div>
    <!--/.footer-bottom-->
</footer>
</body>
